using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class GameController : MonoBehaviour
{
    [SerializeField] int playerLives = 9;
    [SerializeField] int playerCoins = 0;
    [SerializeField] TextMeshProUGUI livesText;
    [SerializeField] TextMeshProUGUI scoreText;
    
    void Awake() 
    {
       int numGameSessions = FindObjectsOfType<GameController>().Length;
       if(numGameSessions > 1){
           Destroy(gameObject);
       }
       else
       {
           DontDestroyOnLoad(gameObject);
       }

   }

   void Start(){
       livesText.text = playerLives.ToString();
       scoreText.text = playerCoins.ToString();
   }
  public void ProcessPlayerDeath(){
      if(playerLives>1)
      {
          TakeLife();
      }
      else
      {
          ResetGameSession();
      } 
  }
  void TakeLife(){
      playerLives--;
      int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
      SceneManager.LoadScene(currentSceneIndex);
      livesText.text = playerLives.ToString();

  }
  public void AddScore(int pointsToAdd)
  {
      playerCoins+=pointsToAdd;
      scoreText.text = playerCoins.ToString();
  }
  
  void ResetGameSession()
  {
      FindObjectOfType<ScenePersist>().ResetScenePersist();
      SceneManager.LoadScene(0);
      Destroy(gameObject);

      }
}
